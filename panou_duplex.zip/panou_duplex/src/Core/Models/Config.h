// src/Core/Models/Config.h
// Parametrii instalației și ai hardware-ului — MODIFICĂ DOAR AICI

#ifndef CONFIG_H
#define CONFIG_H

#include <cstdint>

namespace Config
{
    // =========================================================
    // 1. HARDWARE INSTALAȚIE LIFT
    // =========================================================
    namespace Hardware
    {
        constexpr uint8_t PANEL_FLOOR_DEFAULT = 0;   // Default etaj panou (Etj); suprascris din Service
        constexpr bool SECOND_CALL_DEFAULT = false;  // Default al doilea apel: blocat (setabil Service Box, mb_13)
        constexpr bool CAB_ORDER_DEFAULT = false;    // Default ordine cabine pe LCD: direct (cabina1→LCD1); setabil Service Box, mb_15
        constexpr uint8_t FLOORS = 18;               // Total etaje instalație
        constexpr uint8_t LIFTS = 2;                 // Mod Duplex

        // Marcă persistență prin watchdog scratch: reset declanșat de apăsări rapide buton
        constexpr uint32_t RESET_MAGIC_BUTTON = 0x4C505253UL;  // "LPRS" (buton apel, ReSet)
    }

    namespace Service
    {
        constexpr char PHONE_NUMBER_1[] = "0740.317.707";
        constexpr char PHONE_NUMBER_2[] = "";
    }

    // =========================================================
    // 2. TIMING & TIMEOUT-URI (ms)
    // =========================================================
    namespace Timing
    {
        constexpr uint32_t STANDBY_TIMEOUT_DEFAULT_MS = 15000;   // Default timeout standby ecran
        constexpr uint32_t STANDBY_TIMEOUT_MIN_MS     = 5000;    // Limita inferioară standby (5 s)
        constexpr uint32_t STANDBY_TIMEOUT_MAX_MS     = 300000;  // Limita superioară standby (5 min)
        constexpr uint32_t SHIFT_PERIOD_MS = 30000;      // Perioadă schimb standby
        constexpr uint32_t BUTTON_INHIBIT_MS = 1500;     // Debounce buton după apel
        constexpr uint32_t CALL_TIMEOUT_MS = 60000;      // Timeout unic preluare+execuție apel (≈ cursă completă 0-17)
        constexpr uint32_t RESET_PRESS_WINDOW_MS = 2000; // Fereastra în care trebuie să încapă toate apăsările de reset
        constexpr uint8_t  RESET_PRESS_COUNT = 4;        // Apăsări consecutive în fereastră → reset hardware
        constexpr uint32_t LONG_PRESS_SECOND_CALL_MS = 3000; // Apăsare lungă în Confirmed → al doilea apel (dacă e permis)
        constexpr uint32_t BUTTON_STUCK_MS = 10000;      // Detecție buton blocat
        constexpr uint32_t LED_BLINK_SLOW = 500;         // Perioadă clipire lentă LED
        constexpr uint32_t LED_BLINK_FAST = 150;         // Perioadă clipire rapidă LED
        constexpr uint32_t BOOT_TIME_MS = 5000;         // Timp boot pentru verificarea ecranului
    }

    // =========================================================
    // 3. DISPLAY / LCD — OFFSET-URI ȘI SETĂRI
    // =========================================================
    namespace Display
    {
        constexpr uint32_t SPI_CLOCK = 8000000UL;   // Viteză SPI (8 MHz)

        // Offset-uri pentru ST7735 (depind de variantă chip + PCB)
        // Valori comune: BlackTab=(0,0), GreenTab=(1,2), ST7735S=(32,0)
        constexpr int16_t ROW_START = 1;   // ← Ajustează pentru LCD-ul tău
        constexpr int16_t COL_START = 2;   // ← Ajustează pentru LCD-ul tău

        constexpr uint8_t ROTATION = 0;    // 0=portrait, 1=landscape, etc.
    }

    // =========================================================
    // 4. PROTOCOL SERIAL / RS485
    // =========================================================
    namespace Protocol
    {
        constexpr uint32_t SERIAL_BAUD = 9600;
        constexpr char START_MARKER = '<';
        constexpr char END_MARKER = '>';

        // Timeout fără pachet valid → lift considerat deconectat (Missing)
        // Ajustează în funcție de frecvența transmisiei controller-ului lift
        constexpr uint32_t PACKET_TIMEOUT_MS = 500;   // ← fostele 500ms hardcodate

        // Timpi fizici de stabilizare electrică pentru transceiverul MAX485
        constexpr uint32_t RS485_TX_SETTLE_US = 50;
        constexpr uint32_t RS485_TX_RELEASE_US = 50;
        constexpr uint32_t RS485_LISTEN_SETTLE_US = 10;

        // Carrier sense (CSMA) pe linia de comandă (Serial3): apelul se trimite
        // doar dacă linia a fost liberă cel puțin CALL_CARRIER_QUIET_MS; dacă linia
        // rămâne ocupată, cererea amânată expiră după CALL_PENDING_TIMEOUT_MS
        constexpr uint32_t CALL_CARRIER_QUIET_MS = 10;
        constexpr uint32_t CALL_PENDING_TIMEOUT_MS = 3000;
    }

    // =========================================================
    // 5. AUDIO
    // =========================================================
    namespace Audio
    {
        constexpr uint16_t BUZZER_FREQ = 4000;
        constexpr uint32_t BOOT_BEEP_MS = 80;

        constexpr uint32_t ARRIVAL_FIRST_PULSE_MS = 60;
        constexpr uint32_t ARRIVAL_GAP_MS = 210;
        constexpr uint32_t ARRIVAL_SECOND_PULSE_MS = 360;
        constexpr uint16_t ARRIVAL_FIRST_FREQ = 4200;
        constexpr uint16_t ARRIVAL_SECOND_FREQ = 3800;
        // ArrivalBoth: varianta extinsa (sosire in timpul unei secvente Arrival) —
        // dupa pattern-ul normal urmeaza pauza 360-510 ms si al treilea beep 510-570 ms
        constexpr uint32_t ARRIVAL_BOTH_SECOND_GAP_MS = 510;
        constexpr uint32_t ARRIVAL_BOTH_END_MS = 570;
        // Al treilea beep: la eliberarea cabinei (ocp Busy -> Free) dupa sosire
        constexpr uint32_t FREE_PULSE_MS = 80;
        constexpr uint16_t FREE_FREQ = 3400;

        // Warning: apel apasat cu liftul deja la palier — doua beep-uri ascendente
        constexpr uint32_t WARNING_FIRST_PULSE_MS = 100;
        constexpr uint32_t WARNING_GAP_MS = 200;
        constexpr uint32_t WARNING_SECOND_PULSE_MS = 300;
        constexpr uint16_t WARNING_FIRST_FREQ = 3600;
        constexpr uint16_t WARNING_SECOND_FREQ = 4000;

        constexpr uint32_t ALERT_FIRST_PULSE_MS = 40;
        constexpr uint32_t ALERT_FIRST_GAP_MS = 80;
        constexpr uint32_t ALERT_SECOND_PULSE_MS = 120;
        constexpr uint32_t ALERT_SECOND_GAP_MS = 160;
        constexpr uint32_t ALERT_THIRD_PULSE_MS = 200;
    }
}

#endif // CONFIG_H
