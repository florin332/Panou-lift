// src/Core/Services/Protocol.cpp (UART Nativ + CRC-8-CCITT)

#include "Protocol.h"
#include "Pins.h"
#include "Config.h"
#include "Settings.h"
#include "Arduino.h"
#include <SoftwareSerial.h>
#include <atomic>

namespace Protocol
{
    static SoftwareSerial Serial3(Pins::RS485::CALL_RX, Pins::RS485::CALL_TX);

    // -------------------------------------------------------------------------
    // Constante de format
    // -------------------------------------------------------------------------
    static constexpr char CRC_SEPARATOR = '*';
    static constexpr uint8_t RX_FIELDS = 5;
    static constexpr uint8_t FRAME_BUFFER_SIZE = 40;
    static constexpr uint8_t ANALYZE_BUFFER_SIZE = 96;

    struct RxBuffer {
        char receivedChars[FRAME_BUFFER_SIZE];
        byte ndx;
        boolean recvInProgress;
        boolean newData;
        unsigned long lastValidPacketMillis;
        unsigned long frameStartMillis;   // setat la START, pentru timeout cadru
        boolean frameTimedOut;            // timeout deja contorizat pentru cadrul curent
        char analyzeChars[ANALYZE_BUFFER_SIZE];
        uint8_t analyzeLength;
        boolean analyzeActive;
        boolean analyzeOverflow;
    };

    static RxBuffer rxLift1;
    static RxBuffer rxLift2;

    // -------------------------------------------------------------------------
    // Contoare receptie detaliate: inactive dupa reboot, pornite din Service Box
    // [0]=Lift1, [1]=Lift2
    // -------------------------------------------------------------------------
    static std::atomic<bool> sCountingEnabled[2] = {{false}, {false}};
    static std::atomic<bool> sResetCountersPending[2] = {{false}, {false}};
    static bool sAnalyzeEnabled = false;

    // Carrier sense (CSMA) pe linia de comandă (Serial3):
    // sLastCarrierMillis = momentul ultimei activități RX (orice byte = linie ocupată)
    // Cererile locale și USB au sloturi separate; arbiterul le transmite în ordinea
    // sosirii, numai după perioada de liniște comună.
    static unsigned long sLastCarrierMillis = 0;
    static uint8_t sPendingCallLift = 0;
    static unsigned long sPendingCallMillis = 0;
    static std::atomic<bool> sPassThroughEnabled{false};
    enum class RawFrameState : uint8_t { Empty, Writing, Ready, Reading };
    static std::atomic<RawFrameState> sRawFrameState{RawFrameState::Empty};
    static char sPendingRawFrame[FRAME_BUFFER_SIZE];
    static uint8_t sPendingRawFrameLength = 0;
    static unsigned long sPendingRawFrameMillis = 0;
    static uint32_t sRxFrames[2]      = {0, 0}; // cadre complet delimitate (START...END)
    static uint32_t sRxValid[2]       = {0, 0}; // cadre acceptate (format+CRC+domeniu)
    static uint32_t sRxTimeout[2]     = {0, 0}; // cadru inceput, neterminat in timeout
    static uint32_t sRxFormatError[2] = {0, 0}; // delimitatori/campuri/format invalide
    static uint32_t sRxCrcError[2]    = {0, 0}; // CRC prezent, dar incorect
    static uint32_t sRxDataError[2]   = {0, 0}; // format corect, valori imposibile

    static void transmitFrame(const char* frame, uint8_t length);

    static bool liftToIndex(uint8_t lift, uint8_t &index) {
        if (lift < 1 || lift > 2) return false;
        index = lift - 1;
        return true;
    }

    static void resetCounters(uint8_t index) {
        sRxFrames[index] = sRxValid[index] = sRxTimeout[index] = 0;
        sRxFormatError[index] = sRxCrcError[index] = sRxDataError[index] = 0;
    }

    static void appendAnalyzeByte(RxBuffer &buffer, char value) {
        if (buffer.analyzeLength < sizeof(buffer.analyzeChars)) {
            buffer.analyzeChars[buffer.analyzeLength++] = value;
        } else {
            buffer.analyzeOverflow = true;
        }
    }

    static void emitAnalyzeFrame(const RxBuffer &buffer, uint8_t liftIdx, bool complete) {
        Serial.print("RAW L");
        Serial.print(liftIdx + 1);
        Serial.print(complete ? ":" : " PARTIAL:");
        Serial.write(reinterpret_cast<const uint8_t*>(buffer.analyzeChars), buffer.analyzeLength);
        if (buffer.analyzeOverflow) Serial.print("[TRUNCATED]");
        Serial.println();
    }

    // Rezultatul extragerii unui cadru complet delimitat
    enum class FrameResult : uint8_t { None, FormatError, CrcError, Valid };

    // Rezultatul validarii semantice a payload-ului
    enum class ParseResult : uint8_t { FormatError, DataError, Valid };

    // -------------------------------------------------------------------------
    // CRC-8-CCITT: polinom 0x07, init 0x00, fara reflectare, fara XOR final
    // -------------------------------------------------------------------------
    static uint8_t crc8_ccitt(const char *data) {
        uint8_t crc = 0x00;
        while (*data) {
            crc ^= static_cast<uint8_t>(*data++);
            for (uint8_t i = 0; i < 8; ++i) {
                crc = (crc & 0x80) ? (crc << 1) ^ 0x07 : (crc << 1);
            }
        }
        return crc;
    }

    static bool hexByteFromChars(char high, char low, uint8_t &out) {
        auto nibble = [](char c) -> int8_t {
            if (c >= '0' && c <= '9') return c - '0';
            if (c >= 'A' && c <= 'F') return c - 'A' + 10;
            if (c >= 'a' && c <= 'f') return c - 'a' + 10;
            return -1;
        };
        int8_t h = nibble(high);
        int8_t l = nibble(low);
        if (h < 0 || l < 0) return false;
        out = static_cast<uint8_t>((h << 4) | l);
        return true;
    }

    static void byteToHexUpper(uint8_t value, char out[3]) {
        static constexpr char HEX_CHARS[] = "0123456789ABCDEF";
        out[0] = HEX_CHARS[value >> 4];
        out[1] = HEX_CHARS[value & 0x0F];
        out[2] = '\0';
    }

    static bool esteNumeric(const char *str) {
        if (str == nullptr || *str == '\0') return false;
        if (*str == '-') str++;
        while (*str) {
            if (!isdigit(static_cast<unsigned char>(*str))) return false;
            str++;
        }
        return true;
    }

    // -------------------------------------------------------------------------
    // Etapa 1: extrage cadru <payload*CC> in buffer.
    // Regula de resync: un START primit in timpul unui frame abandoneaza
    // frame-ul curent si incepe unul nou.
    // -------------------------------------------------------------------------
    static FrameResult extrageFrame(RxBuffer &buffer, char payload[FRAME_BUFFER_SIZE]) {
        if (!buffer.newData) return FrameResult::None;
        buffer.newData = false;

        // Cautam separatorul CRC si end marker
        char *sep = strchr(buffer.receivedChars, CRC_SEPARATOR);
        if (sep == nullptr) return FrameResult::FormatError;

        *sep = '\0';
        char *crcStr = sep + 1;

        // CRC trebuie sa fie exact 2 caractere hex uppercase, urmat de end marker
        if (crcStr[0] == '\0' || crcStr[1] == '\0' || crcStr[2] != '\0') return FrameResult::FormatError;
        if (!isxdigit(static_cast<unsigned char>(crcStr[0])) ||
            !isxdigit(static_cast<unsigned char>(crcStr[1]))) return FrameResult::FormatError;

        uint8_t receivedCrc;
        if (!hexByteFromChars(crcStr[0], crcStr[1], receivedCrc)) return FrameResult::FormatError;

        if (crc8_ccitt(buffer.receivedChars) != receivedCrc) return FrameResult::CrcError;

        strncpy(payload, buffer.receivedChars, FRAME_BUFFER_SIZE - 1);
        payload[FRAME_BUFFER_SIZE - 1] = '\0';
        return FrameResult::Valid;
    }

    // -------------------------------------------------------------------------
    // Etapa 2: parseaza payload de forma a,b,c,d,e si valideaza semantic.
    // -------------------------------------------------------------------------
    static ParseResult parseazaPachet(const char* payload, LiftState &rezultat) {
        // Numaram câmpurile
        uint8_t commaCount = 0;
        for (const char *p = payload; *p; p++) {
            if (*p == ',') commaCount++;
        }
        if (commaCount != RX_FIELDS - 1) return ParseResult::FormatError;

        char bufferLocal[FRAME_BUFFER_SIZE];
        strncpy(bufferLocal, payload, sizeof(bufferLocal) - 1);
        bufferLocal[sizeof(bufferLocal) - 1] = '\0';

        // Parsam cele 5 campuri
        char *fields[RX_FIELDS];
        fields[0] = strtok(bufferLocal, ",");
        for (uint8_t i = 1; i < RX_FIELDS; i++) {
            fields[i] = strtok(nullptr, ",");
            if (fields[i] == nullptr) return ParseResult::FormatError;
        }

        // Validare numerica pentru toate campurile
        for (uint8_t i = 0; i < RX_FIELDS; i++) {
            if (!esteNumeric(fields[i])) return ParseResult::FormatError;
        }

        int rawPos = atoi(fields[0]);
        if (rawPos < 0 || rawPos >= Config::Hardware::FLOORS) return ParseResult::DataError;
        rezultat.pos = static_cast<uint8_t>(rawPos);

        int rawEtd = atoi(fields[1]);
        if (rawEtd < 0 || rawEtd >= Config::Hardware::FLOORS) return ParseResult::DataError;
        rezultat.etd = static_cast<uint8_t>(rawEtd);

        int rawOcp = atoi(fields[2]);
        if (rawOcp != 0 && rawOcp != 1) return ParseResult::DataError;
        rezultat.ocp = rawOcp == 1 ? Occupancy::Busy : Occupancy::Free;

        int rawSj = atoi(fields[3]);
        if (rawSj < 0 || rawSj > 2) return ParseResult::DataError;
        rezultat.sj = rawSj == 1 ? Direction::Up : rawSj == 2 ? Direction::Down : Direction::Idle;

        int rawSvc = atoi(fields[4]);
        if (rawSvc != 1 && rawSvc != 2 && rawSvc != 3 && rawSvc != 5) return ParseResult::DataError;
        if (rawSvc == 1) rezultat.svc = ServiceState::Fault;
        else if (rawSvc == 2) rezultat.svc = ServiceState::Revision;
        else if (rawSvc == 3) rezultat.svc = ServiceState::Missing;
        else rezultat.svc = ServiceState::Normal;

        return ParseResult::Valid;
    }

    // -------------------------------------------------------------------------
    // Receptor UART cu resync pe START in timpul receptiei.
    // liftIdx: 0=Lift1, 1=Lift2 (pentru contoare)
    // -------------------------------------------------------------------------
    static void eantioneazaUART(HardwareSerial &serial, RxBuffer &buffer, uint8_t liftIdx) {
        while (serial.available() > 0 && !buffer.newData) {
            char rc = serial.read();

            if (rc == Config::Protocol::START_MARKER) {
                // Resync: un START in timpul unui cadru = cadru abandonat (eroare de format)
                if (buffer.recvInProgress && !buffer.frameTimedOut && sCountingEnabled[liftIdx].load(std::memory_order_relaxed)) {
                    sRxFormatError[liftIdx]++;
                }
                if (buffer.analyzeActive) {
                    emitAnalyzeFrame(buffer, liftIdx, false);
                }
                buffer.recvInProgress = true;
                buffer.frameTimedOut = false;
                buffer.frameStartMillis = millis();
                buffer.ndx = 0;
                buffer.analyzeLength = 0;
                buffer.analyzeOverflow = false;
                buffer.analyzeActive = sAnalyzeEnabled;
                if (buffer.analyzeActive) appendAnalyzeByte(buffer, rc);
                continue;
            }

            if (!buffer.recvInProgress) {
                continue;
            }

            if (rc == Config::Protocol::END_MARKER) {
                if (buffer.analyzeActive) {
                    appendAnalyzeByte(buffer, rc);
                    emitAnalyzeFrame(buffer, liftIdx, true);
                    buffer.analyzeActive = false;
                }
                buffer.receivedChars[buffer.ndx] = '\0';
                buffer.recvInProgress = false;
                buffer.ndx = 0;
                buffer.newData = true;
                // Cadru complet delimitat
                if (sCountingEnabled[liftIdx].load(std::memory_order_relaxed) && !buffer.frameTimedOut) {
                    sRxFrames[liftIdx]++;
                }
                continue;
            }

            if (buffer.ndx < FRAME_BUFFER_SIZE - 1) {
                buffer.receivedChars[buffer.ndx++] = rc;
            }
            if (buffer.analyzeActive) appendAnalyzeByte(buffer, rc);
            // daca bufferul e plin, continuam sa rescriem ultimul caracter
        }
    }

    // -------------------------------------------------------------------------
    // Verifica timeout-ul unui cadru inceput (START fara END in fereastra)
    // -------------------------------------------------------------------------
    static void verificaTimeoutCadru(RxBuffer &buffer, uint8_t liftIdx) {
        if (buffer.recvInProgress && !buffer.frameTimedOut &&
            millis() - buffer.frameStartMillis > Config::Protocol::PACKET_TIMEOUT_MS) {
            buffer.frameTimedOut = true;
            buffer.recvInProgress = false;
            buffer.ndx = 0;
            if (buffer.analyzeActive) {
                emitAnalyzeFrame(buffer, liftIdx, false);
                buffer.analyzeActive = false;
            }
            if (sCountingEnabled[liftIdx].load(std::memory_order_relaxed)) sRxTimeout[liftIdx]++;
        }
    }

    // -------------------------------------------------------------------------
    // Initializare
    // -------------------------------------------------------------------------
    void init() {
        Serial1.setRX(Pins::RS485::LIFT2_RX);
        Serial2.setRX(Pins::RS485::LIFT1_RX);
        Serial1.begin(Config::Protocol::SERIAL_BAUD);
        Serial2.begin(Config::Protocol::SERIAL_BAUD);
        Serial3.begin(Config::Protocol::SERIAL_BAUD);
        // RX armat permanent: carrier sense-ul din update() monitorizează linia de
        // comandă și amână trimiterea apelului cât timp există trafic
        Serial3.listen();
        pinMode(Pins::RS485::TX_ENABLE, OUTPUT);
        digitalWrite(Pins::RS485::TX_ENABLE, LOW);
        memset(&rxLift1, 0, sizeof(RxBuffer));
        memset(&rxLift2, 0, sizeof(RxBuffer));
        rxLift1.lastValidPacketMillis = millis();
        rxLift2.lastValidPacketMillis = millis();
        // Dupa reboot numararea este inactiva si contoarele sunt zero
        sCountingEnabled[0].store(false, std::memory_order_relaxed);
        sCountingEnabled[1].store(false, std::memory_order_relaxed);
        sResetCountersPending[0].store(false, std::memory_order_relaxed);
        sResetCountersPending[1].store(false, std::memory_order_relaxed);
        sAnalyzeEnabled = false;
        resetCounters(0);
        resetCounters(1);
        sPassThroughEnabled.store(false, std::memory_order_relaxed);
        sRawFrameState.store(RawFrameState::Empty, std::memory_order_relaxed);
        sPendingCallLift = 0;
        sPendingRawFrameLength = 0;
    }

    // -------------------------------------------------------------------------
    // Update principal
    // -------------------------------------------------------------------------
    void update(SharedPanel &localPanel) {
        char payload[FRAME_BUFFER_SIZE];

        for (uint8_t i = 0; i < 2; i++) {
            if (sResetCountersPending[i].exchange(false, std::memory_order_relaxed)) {
                resetCounters(i);
            }
        }

        // Carrier sense: orice byte recepționat pe linia de comandă înseamnă linie
        // ocupată. Conținutul nu contează — doar activitatea marchează carrier-ul.
        while (Serial3.available() > 0) {
            Serial3.read();
            sLastCarrierMillis = millis();
        }

        const unsigned long now = millis();
        if (sPendingCallLift != 0) {
            if (now - sPendingCallMillis >= Config::Protocol::CALL_PENDING_TIMEOUT_MS) {
                sPendingCallLift = 0;
            }
        }

        RawFrameState rawState = sRawFrameState.load(std::memory_order_acquire);
        if (rawState == RawFrameState::Ready && !sPassThroughEnabled.load(std::memory_order_acquire)) {
            sRawFrameState.compare_exchange_strong(rawState, RawFrameState::Empty,
                                                   std::memory_order_acq_rel);
            rawState = sRawFrameState.load(std::memory_order_acquire);
        }
        if (rawState == RawFrameState::Ready &&
            now - sPendingRawFrameMillis >= Config::Protocol::CALL_PENDING_TIMEOUT_MS) {
            sRawFrameState.compare_exchange_strong(rawState, RawFrameState::Empty,
                                                   std::memory_order_acq_rel);
            rawState = sRawFrameState.load(std::memory_order_acquire);
        }

        const bool localPending = sPendingCallLift != 0;
        const bool rawPending = rawState == RawFrameState::Ready;
        if ((localPending || rawPending) &&
            now - sLastCarrierMillis >= Config::Protocol::CALL_CARRIER_QUIET_MS) {
            const bool rawFirst = rawPending && (!localPending ||
                static_cast<int32_t>(sPendingCallMillis - sPendingRawFrameMillis) >= 0);
            if (rawFirst) {
                RawFrameState expected = RawFrameState::Ready;
                if (sRawFrameState.compare_exchange_strong(expected, RawFrameState::Reading,
                                                           std::memory_order_acq_rel)) {
                    char frame[FRAME_BUFFER_SIZE];
                    const uint8_t length = sPendingRawFrameLength;
                    memcpy(frame, sPendingRawFrame, length);
                    sRawFrameState.store(RawFrameState::Empty, std::memory_order_release);
                    if (sPassThroughEnabled.load(std::memory_order_acquire)) {
                        transmitFrame(frame, length);
                    }
                }
            } else if (localPending) {
                const uint8_t lift = sPendingCallLift;
                sPendingCallLift = 0;
                trimiteApel(lift);
            }
        }

        eantioneazaUART(Serial2, rxLift1, 0);
        verificaTimeoutCadru(rxLift1, 0);
        FrameResult frame1 = extrageFrame(rxLift1, payload);
        if (frame1 == FrameResult::Valid) {
            LiftState tempState;
            ParseResult parsed = parseazaPachet(payload, tempState);
            if (parsed == ParseResult::Valid) {
                localPanel.lift1 = tempState;
                rxLift1.lastValidPacketMillis = millis();
                if (sCountingEnabled[0].load(std::memory_order_relaxed)) sRxValid[0]++;
            } else if (sCountingEnabled[0].load(std::memory_order_relaxed)) {
                if (parsed == ParseResult::FormatError) sRxFormatError[0]++;
                else sRxDataError[0]++;
            }
        } else if (frame1 == FrameResult::CrcError) {
            if (sCountingEnabled[0].load(std::memory_order_relaxed)) sRxCrcError[0]++;
        } else if (frame1 == FrameResult::FormatError) {
            if (sCountingEnabled[0].load(std::memory_order_relaxed)) sRxFormatError[0]++;
        }
        if (millis() - rxLift1.lastValidPacketMillis > Config::Protocol::PACKET_TIMEOUT_MS) {
            localPanel.lift1.svc = ServiceState::Missing;
        }

        eantioneazaUART(Serial1, rxLift2, 1);
        verificaTimeoutCadru(rxLift2, 1);
        FrameResult frame2 = extrageFrame(rxLift2, payload);
        if (frame2 == FrameResult::Valid) {
            LiftState tempState;
            ParseResult parsed = parseazaPachet(payload, tempState);
            if (parsed == ParseResult::Valid) {
                localPanel.lift2 = tempState;
                rxLift2.lastValidPacketMillis = millis();
                if (sCountingEnabled[1].load(std::memory_order_relaxed)) sRxValid[1]++;
            } else if (sCountingEnabled[1].load(std::memory_order_relaxed)) {
                if (parsed == ParseResult::FormatError) sRxFormatError[1]++;
                else sRxDataError[1]++;
            }
        } else if (frame2 == FrameResult::CrcError) {
            if (sCountingEnabled[1].load(std::memory_order_relaxed)) sRxCrcError[1]++;
        } else if (frame2 == FrameResult::FormatError) {
            if (sCountingEnabled[1].load(std::memory_order_relaxed)) sRxFormatError[1]++;
        }
        if (millis() - rxLift2.lastValidPacketMillis > Config::Protocol::PACKET_TIMEOUT_MS) {
            localPanel.lift2.svc = ServiceState::Missing;
        }

        // Exportam contoarele catre Core 0 prin memoria partajata
        localPanel.comm.lift1.rxFrames      = sRxFrames[0];
        localPanel.comm.lift1.rxValid       = sRxValid[0];
        localPanel.comm.lift1.rxTimeout     = sRxTimeout[0];
        localPanel.comm.lift1.rxFormatError = sRxFormatError[0];
        localPanel.comm.lift1.rxCrcError    = sRxCrcError[0];
        localPanel.comm.lift1.rxDataError   = sRxDataError[0];
        localPanel.comm.lift2.rxFrames      = sRxFrames[1];
        localPanel.comm.lift2.rxValid       = sRxValid[1];
        localPanel.comm.lift2.rxTimeout     = sRxTimeout[1];
        localPanel.comm.lift2.rxFormatError = sRxFormatError[1];
        localPanel.comm.lift2.rxCrcError    = sRxCrcError[1];
        localPanel.comm.lift2.rxDataError   = sRxDataError[1];
        localPanel.comm.countingEnabled[0]  = sCountingEnabled[0].load(std::memory_order_relaxed) ? 1 : 0;
        localPanel.comm.countingEnabled[1]  = sCountingEnabled[1].load(std::memory_order_relaxed) ? 1 : 0;
    }

    // -------------------------------------------------------------------------
    // API de control apelat de Core 0; starea atomica este consumata de Core 1.
    // -------------------------------------------------------------------------
    bool commCountEnable(uint8_t lift) {
        uint8_t index;
        if (!liftToIndex(lift, index)) return false;
        sCountingEnabled[index].store(true, std::memory_order_relaxed);
        return true;
    }

    bool commCountDisable(uint8_t lift) {
        uint8_t index;
        if (!liftToIndex(lift, index)) return false;
        sCountingEnabled[index].store(false, std::memory_order_relaxed);
        return true;
    }

    bool commCountReset(uint8_t lift) {
        uint8_t index;
        if (!liftToIndex(lift, index)) return false;
        sResetCountersPending[index].store(true, std::memory_order_relaxed);
        return true;
    }

    bool commCountIsEnabled(uint8_t lift) {
        uint8_t index;
        return liftToIndex(lift, index) && sCountingEnabled[index].load(std::memory_order_relaxed);
    }

    void commAnalyzeEnable() {
        sAnalyzeEnabled = true;
        rxLift1.analyzeActive = false;
        rxLift2.analyzeActive = false;
    }

    void commAnalyzeDisable() {
        sAnalyzeEnabled = false;
        if (rxLift1.analyzeActive) {
            emitAnalyzeFrame(rxLift1, 0, false);
            rxLift1.analyzeActive = false;
        }
        if (rxLift2.analyzeActive) {
            emitAnalyzeFrame(rxLift2, 1, false);
            rxLift2.analyzeActive = false;
        }
    }

    // -------------------------------------------------------------------------
    // Cerere de apel cu carrier sense: pusă în așteptare, servită de update()
    // -------------------------------------------------------------------------
    void requestCall(uint8_t ascAlocat) {
        if (ascAlocat == 0) return;
        sPendingCallLift = ascAlocat;
        sPendingCallMillis = millis();
    }

    void setPassThroughEnabled(bool enabled) {
        sPassThroughEnabled.store(enabled, std::memory_order_release);
        if (!enabled) {
            RawFrameState expected = RawFrameState::Ready;
            sRawFrameState.compare_exchange_strong(expected, RawFrameState::Empty,
                                                   std::memory_order_acq_rel);
        }
    }

    bool isPassThroughEnabled() {
        return sPassThroughEnabled.load(std::memory_order_acquire);
    }

    bool queuePassThroughFrame(const char* frame, uint8_t length) {
        if (frame == nullptr || length < 2 || length >= FRAME_BUFFER_SIZE ||
            frame[0] != Config::Protocol::START_MARKER ||
            frame[length - 1] != Config::Protocol::END_MARKER ||
            !sPassThroughEnabled.load(std::memory_order_acquire)) {
            return false;
        }

        RawFrameState expected = RawFrameState::Empty;
        if (!sRawFrameState.compare_exchange_strong(expected, RawFrameState::Writing,
                                                    std::memory_order_acq_rel)) {
            return false;
        }

        memcpy(sPendingRawFrame, frame, length);
        sPendingRawFrameLength = length;
        sPendingRawFrameMillis = millis();
        if (!sPassThroughEnabled.load(std::memory_order_acquire)) {
            sRawFrameState.store(RawFrameState::Empty, std::memory_order_release);
            return false;
        }
        sRawFrameState.store(RawFrameState::Ready, std::memory_order_release);
        return true;
    }

    // -------------------------------------------------------------------------
    // Transmisie apel cu acelasi format <payload*CC>
    // -------------------------------------------------------------------------
    static void transmitFrame(const char* frame, uint8_t length) {
        if (frame == nullptr || length == 0) return;
        Serial3.listen();
        delayMicroseconds(Config::Protocol::RS485_LISTEN_SETTLE_US);
        digitalWrite(Pins::RS485::TX_ENABLE, HIGH);
        delayMicroseconds(Config::Protocol::RS485_TX_SETTLE_US);
        Serial3.write(reinterpret_cast<const uint8_t*>(frame), length);
        Serial3.flush();
        delayMicroseconds(Config::Protocol::RS485_TX_RELEASE_US);
        digitalWrite(Pins::RS485::TX_ENABLE, LOW);
        sLastCarrierMillis = millis();
    }

    void trimiteApel(uint8_t ascAlocat) {
        if (ascAlocat == 0) return;

        char payload[16];
        snprintf(payload, sizeof(payload), "%u,%u", ascAlocat, Settings::panelFloor());
        uint8_t crc = crc8_ccitt(payload);
        char crcStr[3];
        byteToHexUpper(crc, crcStr);
        char frame[FRAME_BUFFER_SIZE];
        const int length = snprintf(frame, sizeof(frame), "%c%s*%s%c",
                                    Config::Protocol::START_MARKER, payload, crcStr,
                                    Config::Protocol::END_MARKER);
        if (length > 0 && length < static_cast<int>(sizeof(frame))) {
            transmitFrame(frame, static_cast<uint8_t>(length));
        }
    }
}
